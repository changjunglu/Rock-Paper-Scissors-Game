import { defineConfig } from 'vitepress'

// https://vitepress.vuejs.org/config/app-configs
export default defineConfig({
  title: '剪刀石頭布追逐遊戲',
  description: '完整專案文檔',
  base: '/',
  lang: 'zh-TW',
  themeConfig: {
    nav: [
      { text: '首頁', link: '/' },
      { text: '專案說明', link: '/README' },
      { text: '測試頁面', link: '/test' }
    ],
    sidebar: [
      {
        text: '專案資訊',
        items: [
          { text: '專案說明', link: '/README' }
        ]
      },
      {
        text: '產品文檔',
        items: [
          { text: '業務需求說明書 (BRD)', link: '/brd' },
          { text: '產品需求說明書 (PRD)', link: '/prd' }
        ]
      },
      {
        text: '需求文檔',
        items: [
          { text: '高階 User Story', link: '/userstory_high' },
          { text: '功能需求說明書 (FRD)', link: '/frd' },
          { text: '功能級 User Story', link: '/userstory_func' }
        ]
      },
      {
        text: '技術文檔',
        items: [
          { text: '系統需求說明書 (SRD)', link: '/srd' },
          { text: 'API 設計文件', link: '/api' },
          { text: '資料庫設計文件', link: '/db' }
        ]
      },
      {
        text: '設計文檔',
        items: [
          { text: 'UI/UX 設計說明文件', link: '/uiux' }
        ]
      },
      {
        text: '其他',
        items: [
          { text: '測試頁面', link: '/test' }
        ]
      }
    ]
  },
  markdown: {
    theme: 'github-light',
    lineNumbers: true
  }
})
